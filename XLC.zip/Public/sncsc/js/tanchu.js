function tanchu(str){
	alert(str);
}
